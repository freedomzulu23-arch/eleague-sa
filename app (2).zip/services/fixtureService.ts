import { supabase } from "../lib/supabase";
import { generateFixtures } from "../lib/fixtures";

export async function generateLeagueFixtures(leagueId: string) {
  // Load league
  const { data: league, error: leagueError } = await supabase
    .from("leagues")
    .select("*")
    .eq("id", leagueId)
    .single();

  if (leagueError) throw leagueError;

  if (league.fixtures_generated) {
    throw new Error("Fixtures have already been generated.");
  }

  // Load teams
  const { data: teams, error: teamError } = await supabase
    .from("league_teams")
    .select("id, team_name")
    .eq("league_id", leagueId);

  if (teamError) throw teamError;

  if (!teams || teams.length < 2) {
    throw new Error("At least two teams are required.");
  }

  // Generate fixtures
  const fixtures = generateFixtures(
    teams,
    league.home_away === true
  );

  // Prepare rows for database
  const rows = fixtures.map((fixture) => ({
    league_id: leagueId,
    round: fixture.round,
    home_team_id: fixture.home_team_id,
    away_team_id: fixture.away_team_id,
    home_score: 0,
    away_score: 0,
    played: false,
    match_date: null,
    match_time: null,
  }));

  // Save fixtures
  const { error: insertError } = await supabase
    .from("fixtures")
    .insert(rows);

  if (insertError) throw insertError;

  // Mark league as generated
  const { error: updateError } = await supabase
    .from("leagues")
    .update({
      fixtures_generated: true,
    })
    .eq("id", leagueId);

  if (updateError) throw updateError;

  return true;
}